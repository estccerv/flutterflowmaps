import '/backend/schema/structs/index.dart';

class UserPresenceCloudCloudFunctionCallResponse {
  UserPresenceCloudCloudFunctionCallResponse({
    this.errorCode,
    this.succeeded,
    this.jsonBody,
  });
  String? errorCode;
  bool? succeeded;
  dynamic jsonBody;
}

class CreateDeliveriesNotificationCloudFunctionCallResponse {
  CreateDeliveriesNotificationCloudFunctionCallResponse({
    this.errorCode,
    this.succeeded,
    this.jsonBody,
    this.resultAsString,
    this.data,
  });
  String? errorCode;
  bool? succeeded;
  dynamic jsonBody;
  String? resultAsString;
  dynamic data;
}

class GetGoogleDirectionsCloudFunctionCallResponse {
  GetGoogleDirectionsCloudFunctionCallResponse({
    this.errorCode,
    this.succeeded,
    this.jsonBody,
    this.resultAsString,
    this.data,
  });
  String? errorCode;
  bool? succeeded;
  dynamic jsonBody;
  String? resultAsString;
  dynamic data;
}
