// Export pages
export '/pages/static_map/static_map_widget.dart' show StaticMapWidget;
export '/login/login_widget.dart' show LoginWidget;
export '/google_map/google_map_widget.dart' show GoogleMapWidget;
export '/pages/tripper/tripper_widget.dart' show TripperWidget;
export '/pages/business/business_widget.dart' show BusinessWidget;
export '/pages/acceptance/acceptance_widget.dart' show AcceptanceWidget;
export '/pages/alldeliveries/alldeliveries_widget.dart'
    show AlldeliveriesWidget;
