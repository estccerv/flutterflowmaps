import '/components/active_button_widget.dart';
import '/components/debug_widget.dart';
import '/flutter_flow/flutter_flow_animations.dart';
import '/flutter_flow/flutter_flow_google_map.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:math';
import 'google_map_widget.dart' show GoogleMapWidget;
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:pointer_interceptor/pointer_interceptor.dart';
import 'package:provider/provider.dart';

class GoogleMapModel extends FlutterFlowModel<GoogleMapWidget> {
  ///  State fields for stateful widgets in this page.

  // State field(s) for GoogleMap widget.
  LatLng? googleMapsCenter;
  final googleMapsController = Completer<GoogleMapController>();
  // Model for Debug component.
  late DebugModel debugModel;
  // Model for activeButton component.
  late ActiveButtonModel activeButtonModel;

  @override
  void initState(BuildContext context) {
    debugModel = createModel(context, () => DebugModel());
    activeButtonModel = createModel(context, () => ActiveButtonModel());
  }

  @override
  void dispose() {
    debugModel.dispose();
    activeButtonModel.dispose();
  }
}
