import '/auth/firebase_auth/auth_util.dart';
import '/components/debug_widget.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/custom_code/widgets/index.dart' as custom_widgets;
import 'tripper_widget.dart' show TripperWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class TripperModel extends FlutterFlowModel<TripperWidget> {
  ///  State fields for stateful widgets in this page.

  // Model for Debug component.
  late DebugModel debugModel;

  @override
  void initState(BuildContext context) {
    debugModel = createModel(context, () => DebugModel());
  }

  @override
  void dispose() {
    debugModel.dispose();
  }
}
