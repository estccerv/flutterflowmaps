import '/components/active_button_widget.dart';
import '/components/debug_widget.dart';
import '/flutter_flow/flutter_flow_animations.dart';
import '/flutter_flow/flutter_flow_static_map.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/lat_lng.dart';
import 'dart:math';
import 'package:mapbox_search/mapbox_search.dart' as mapbox;
import 'static_map_widget.dart' show StaticMapWidget;
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class StaticMapModel extends FlutterFlowModel<StaticMapWidget> {
  ///  State fields for stateful widgets in this page.

  // Model for Debug component.
  late DebugModel debugModel;
  // Model for activeButton component.
  late ActiveButtonModel activeButtonModel;

  @override
  void initState(BuildContext context) {
    debugModel = createModel(context, () => DebugModel());
    activeButtonModel = createModel(context, () => ActiveButtonModel());
  }

  @override
  void dispose() {
    debugModel.dispose();
    activeButtonModel.dispose();
  }
}
