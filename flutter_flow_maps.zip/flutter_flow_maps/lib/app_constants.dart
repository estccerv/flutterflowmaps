import 'package:flutter/material.dart';
import 'flutter_flow/flutter_flow_util.dart';

abstract class FFAppConstants {
  static const String mapbox =
      'pk.eyJ1Ijoibmlja3kyMjA1IiwiYSI6ImNtOXZoODk3ajBsM2sybHB3MW12NGhpcHUifQ.OdeDm6DAQnLAcXFJZRwWQw';
}
