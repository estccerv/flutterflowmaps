package com.mycompany.flutterflowmaps

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
